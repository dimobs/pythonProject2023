from project.cat import Cat
from project.dog import Dog

c = Cat()
d = Dog()

print(c.eat())
print(d.eat())
